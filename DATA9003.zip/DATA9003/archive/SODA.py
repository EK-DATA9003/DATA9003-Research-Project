# IMPORTANT: This module is obsolete
# The Socrata Open Data API (SODA) can be used to query the NYPD arrests dataset.
# While suitable for querying subsets or aggregations usage limits prevent loading the entire dataset in this fashion
# Consequently we transitioned to loading the dataset locally and have declared this module obsolete


from sodapy import Socrata
import pandas as pd
import matplotlib.pyplot as plt


# OBJECT TYPE: Function
# RETURN TYPE: Pandas DataFrame (Pivot Table) + Plot (saved as jpeg)
# NAME:  ArrestsPerYear
# AUTHOR:  Eoin Keohane
# LAST ALTERED: 06/07/2022 (EK)
# DESCRIPTION:  SODA query to get the number of arrests in each borough annually. Plot the results.

def ArrestsPerYear_SODA(apptoken):
    # connection details
    url = "data.cityofnewyork.us"
    dataID = "8h9b-rp9u"

    # estalish connection to the Socrata API
    client = Socrata(url,
                     app_token=apptoken)
    client.timeout = 90

    # specify query
    select = "date_trunc_y(ARREST_DATE) as Year, ARREST_BORO AS Borough, COUNT(*) AS Arrests",
    group = "Year, Borough"

    # BOROUGHS:
    # B - bronx
    # K - brooklyn
    # M - manhattan
    # Q - queens
    # S - staten

    # execute query
    res = client.get_all(dataID,
                         select=select,
                         group=group)

    # socrata returns a generator (results are paginated)
    # move the results into a single list and use that list to make a dataframe
    mylist = [item for item in res]
    DF = pd.DataFrame(mylist)

    # all variables are returned as strings
    # convert count to numeric (year used as index -> leave as string but slice for easier reading)
    DF["Arrests"] = pd.to_numeric(DF["Arrests"])
    DF["Year"] = DF["Year"].str.slice(0, 4)

    # create pivot table from dataframe
    PivotTable = pd.pivot_table(DF,
                                index="Year",
                                columns="Borough")

    # plot the pivot table
    ax = PivotTable.plot(kind="bar",
                         figsize=(12, 8),
                         fontsize=12)
    # add title
    ax.set_title("Arrests per Year by Borough",
                 fontsize="16")

    # save the resulting figure
    plt.savefig("arrests_yr.jpg")

    # remember to close the connection
    client.close()
    return PivotTable


# OBJECT TYPE: Function
# RETURN TYPE: generator
# NAME:  GetSubset
# AUTHOR:  Eoin Keohane
# LAST ALTERED: 06/07/2022 (EK)
# DESCRIPTION:  SODA query to get a subset of the NYPD arrests dataset

def GetSubset(apptoken, yr1, yr2):
    # connection details
    url = "data.cityofnewyork.us"
    dataID = "8h9b-rp9u"

    client = Socrata(url,
                     app_token=apptoken)
    client.timeout = 90

    # specify query
    select = "arrest_date, date_trunc_ym(arrest_date) as month, law_code, arrest_boro, longitude, latitude",

    # only get arrests for infractions of penal law (PL) from yr1 to yr2
    where = "(arrest_date BETWEEN '{}-01-01' AND '{}-12-31') AND starts_with(law_code, 'PL')".format(yr1, yr2)

    order = "arrest_date ASC"

    res = client.get_all(dataID,
                         where=where,
                         select=select,
                         order=order)

    client.close()

    # this will return a generator object containing the paginated results of our query
    # NOTE: API usage limits may restrict the amount of data that can be loaded this way
    return res