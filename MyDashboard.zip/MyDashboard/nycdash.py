from dash import Dash
import dash_core_components as dcc
import dash_html_components as html
import dash_bootstrap_components as dbc
import pandas as pd
import numpy as np
from dash.dependencies import Input, Output
import plotly.express as px

import homepage as home
import crimepage as crime
import salespage as sales
import amenitypage as misc

from DATA9003.exploration.PlotArrests import HeatMap_Dynamic
from DATA9003.exploration.PlotSales import SalesChoropleth

arrests_df = pd.read_csv("./assets/arrestsdata.csv")
sales_df = pd.read_csv("./assets/salesdata.csv",
                       parse_dates=[10])

# create navigation bar
nav_item = dbc.NavItem(dbc.NavLink("Home", href="/"))
nav_drop = dbc.DropdownMenu(
    children=[dbc.DropdownMenuItem("Crime", href="/crime"),
              dbc.DropdownMenuItem("Property Sales", href="/sales"),
              dbc.DropdownMenuItem("Public Amenities", href="/misc")],
    nav=True,
    in_navbar=True,
    label="Menu"
)

navbar = dbc.NavbarSimple(
    children=[nav_item, nav_drop],
    brand="DATA9003: Research Project",
    brand_href="/",
    sticky="top",
    color="primary",
    dark=True
)

# initialise app
app = Dash(__name__,
                external_stylesheets=[dbc.themes.SLATE],
                suppress_callback_exceptions=True,
                meta_tags=[{"name": "viewport",
                              "content": "width=device-width"}])


# define app layout
app.layout = html.Div([
    navbar,
    dcc.Location(id='url', refresh=False),
    html.Div(id='page-content', children=[])
])


# change page with navbar
@app.callback(Output('page-content', 'children'),
              [Input('url', 'pathname')])
def display_page(pathname):
    if pathname == '/':
        return home.layout
    if pathname == '/crime':
        return crime.layout(app)
    if pathname == '/sales':
        return sales.layout
    if pathname == '/misc':
        return misc.layout
    else:
        return "404 ERROR: PAGE NOT FOUND"


# annual arrests bar chart
@app.callback(Output('annual-arrests', 'figure'),
              [Input('crime-boro', 'value')])
def annualarrests(value):
    df = arrests_df.loc[arrests_df["arrest_boro"].isin(value)]

    df = df.groupby(["year", "arrest_boro"]).agg("count")
    df.reset_index(inplace=True)

    df = df[["year", "arrest_boro", "arrest_key"]]
    df.columns = ["Year", "Borough", "Count"]

    fig = px.bar(df,
                 x="Year",
                 y="Count",
                 color="Borough",
                 barmode="group",
                 title="Annual Arrests by Borough",
                 template="plotly_dark")

    fig.update_layout({
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'paper_bgcolor': 'rgba(0,0,0,0)',
    })

    return fig


# offence type bar chart
@app.callback(Output('ofns-type', 'figure'),
              [Input('crime-boro', 'value')])
def ofnstype(value):
    df = arrests_df.loc[arrests_df["arrest_boro"].isin(value)]

    df = df.groupby(["ofns_type", "arrest_boro"]).agg("count")
    df.reset_index(inplace=True)

    df = df[["ofns_type", "arrest_boro", "arrest_key"]]
    df.columns = ["Offence Type", "Borough", "Count"]
    fig = px.bar(df,
                 x="Offence Type",
                 y="Count",
                 color="Borough",
                 barmode="group",
                 title="Arrests by Offence Type",
                 template="plotly_dark")

    fig.update_layout({
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'paper_bgcolor': 'rgba(0,0,0,0)',
    })

    return fig


# arrests heatmap
@app.callback(Output('heatmap', 'srcDoc'),
              [Input('crime-boro', 'value')])
def arrestsmap(boros):
    mydf = arrests_df.loc[arrests_df.arrest_boro.isin(boros)]

    mymap = HeatMap_Dynamic(mydf, timestep="quarter", FigDir="./assets")

    return open("./assets/DynamicHeatMap.html", "r").read()


# annual sales bar chart
@app.callback(Output('annual-sales', 'figure'),
              [Input('sale-boro', 'value')])
def annualsales(value):
    df = sales_df.loc[sales_df["borough"].isin(value)]

    df = df.groupby(["year", "borough"]).agg("count")
    df.reset_index(inplace=True)

    df = df[["year", "borough", "zipcode"]]
    df.columns = ["Year", "Borough", "Count"]
    fig = px.bar(df,
                 x="Year",
                 y="Count",
                 color="Borough",
                 barmode="group",
                 title="Annual Sales",
                 template="plotly_dark")

    fig.update_layout({
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'paper_bgcolor': 'rgba(0,0,0,0)',
    })

    return fig


# median price over time line chart
@app.callback(Output('median-price', 'figure'),
              [Input('sale-boro', 'value')])
def medianprice(value):
    df = sales_df.loc[sales_df["borough"].isin(value)]

    df = df.groupby(["borough", "year"]).agg({"sale_price": np.median})
    df.reset_index(inplace=True)

    fig = px.line(df,
                  x="year",
                  y="sale_price",
                  color="borough",
                  title="Median Price Over Time",
                  template="plotly_dark")

    fig.update_layout({
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'paper_bgcolor': 'rgba(0,0,0,0)',
    })

    return fig


# sale price boxplot
@app.callback(Output('price-dist', 'figure'),
              [Input('sale-boro', 'value')])
def pricedist(value):
    df = sales_df.loc[sales_df["borough"].isin(value)]

    fig = px.box(df,
                 x="sale_price",
                 y="borough",
                 title="Distribution of Sale Prices",
                 template="plotly_dark")

    fig.update_layout({
        'plot_bgcolor': 'rgba(0,0,0,0)',
        'paper_bgcolor': 'rgba(0,0,0,0)',
    })

    return fig


@app.callback(Output('pricechoro', 'srcDoc'),
              Input('sale-boro', 'value'),
              Input('sale-year', 'value'))
def salechoropleth(boros, yr):
    df = sales_df.loc[sales_df["borough"].isin(boros)]
    YearOfInterest = int(yr)

    mymap = SalesChoropleth(df, YearOfInterest, FigDir='./assets')

    return open("./assets/PriceChoro.html", "r").read()


# reload map based on checklist
@app.callback(Output('amenitiesmap', 'srcDoc'),
              [Input('amenity', 'value')])
def amenitymap(value):
    htmlfile = "./assets/"+value
    return open(htmlfile, "r").read()


if __name__ == '__main__':
    app.run_server(debug=False)
