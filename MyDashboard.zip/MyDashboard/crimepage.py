import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc

import pandas as pd

crimedata = pd.read_csv("./assets/arrestsdata.csv")

def layout(myapp):

    mylayout = dbc.Container([
        dbc.Row([
            html.Center(html.H1("Crime Hot-Spots")),
            html.Br(),
            html.Hr()
        ]),
        dbc.Row([

            dbc.Col([
                html.P(
                    "Crime hot-spots are identified based on concentrations of arrests made by the New York City Police Department (NYPD)."),
                html.P(
                    "Data for the arrests made by the NYPD between the years 2006 and 2020 is taken from New York City's OpenData portal."),
                html.P("This heatmap shows the geographic distribution of arrests over time"),
                html.P("Arrests are concentrated at various locations across the five boroughs."),

                html.P("Select Boroughs of Interest (map may take some time to refresh):"),
                dcc.Checklist(options=[{'label': ' Manhattan', 'value': 'M'},
                                       {'label': ' Brooklyn', 'value': 'K'},
                                       {'label': ' The Bronx', 'value': 'B'},
                                       {'label': ' Queens', 'value': 'Q'},
                                       {'label': ' Staten Island', 'value': 'S'}],
                              value=['M', 'K', 'B', 'Q', 'S'],
                              labelStyle={'display': 'block'},
                              id='crime-boro')
            ]),
            dbc.Col([html.Iframe(id='heatmap',
                                 srcDoc=open("./assets/DynamicHeatMap.html", "r").read(),
                                 style={'height':'500px',
                                        'width':'100%'})])
        ]),
        dbc.Row([
            dbc.Col([dcc.Graph(id="annual-arrests")]),
            dbc.Col([dcc.Graph(id="ofns-type")])
        ])
    ])



    return mylayout
