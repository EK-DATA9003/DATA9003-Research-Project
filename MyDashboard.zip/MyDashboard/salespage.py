import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc

layout = dbc.Container([
    dbc.Row([
        html.Center(html.H1("Property Sales")),
        html.Br(),
        html.Hr()
    ]),
    dbc.Row([
        dbc.Col([
            html.P(
                "Annual sales data for properties in New York City is published by the New York City Department of Finance"),
            html.P(
                "For this project we will only consider sales of one-family homes and single-unit condominiums"),
            html.P(
                "This map shows the median sale price of properties within each zipcode for the selected year"),

            html.P("Select Boroughs of Interest:"),
            dcc.Checklist(options=[{'label': ' Brooklyn', 'value': 'B'},
                                   {'label': ' The Bronx', 'value': 'X'},
                                   {'label': ' Queens', 'value': 'Q'},
                                   {'label': ' Staten Island', 'value': 'SI'}],
                          value=['B', 'X', 'Q', 'SI'],
                          labelStyle={'display': 'block'},
                          id='sale-boro')
        ]),
        dbc.Col([
            dcc.Dropdown(id='sale-year',
                         options=[{'label': str(yr), 'value': yr} for yr in range(2006, 2021)],
                         value=2006),
            html.Iframe(id='pricechoro',
                        srcDoc=open("./assets/PriceChoro.html", "r").read(),
                        style={'height': '500px',
                               'width': '100%'})])
    ]),
    dbc.Row([
        dbc.Col([dcc.Graph(id="annual-sales")]),
        dbc.Col([dcc.Graph(id="median-price")])
    ]),
    dbc.Row([
        dbc.Col([dcc.Graph(id="price-dist")])
    ])
])