import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc

txt1 = open("assets/summary.txt").read()
txt2 = open("assets/conclusions.txt").read()

layout = dbc.Container([
    dbc.Row([
        html.Center(html.H1("The Impact of Crime Hot-Spots on House Prices")),
        html.Br(),
        html.Hr()
    ]),
    dbc.Row([
            html.P(txt1)
    ]),
    dbc.Row([
        dbc.Col(html.Img(src="./assets/dist2crime.jpg",
                         style={"width":"100%",
                                "height":"75%"})),
        dbc.Col(html.P(txt2))
    ])
])