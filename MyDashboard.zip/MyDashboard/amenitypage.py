import dash_html_components as html
import dash_core_components as dcc
import dash_bootstrap_components as dbc

layout = dbc.Container([
    dbc.Row([
        html.Center(html.H1("Public Amenities")),
        html.Br(),
        html.Hr()
    ]),
    dbc.Row([
        dbc.Col([
            html.P("The house sales data does not provide fine details on the characteristics of each home sold, only giving details of the address, age and square-footage of the property"),
            html.P("In an effort to include more potentially relevant property attributes the dataset was supplemented, not only with the distance to the nearest crime hotspot, but also with the distances to various amenities. In particular schools, parks and transport hubs"),
            dcc.Dropdown(id="amenity",
                         options=[{'label': 'Parks', 'value': 'parkmarker.html'},
                                  {'label': 'Schools', 'value': 'schoolmarker.html'},
                                  {'label': 'Transport Hubs', 'value': 'sbwymarker.html'}],
                         value='Parks'),
            html.Iframe(id='amenitiesmap',
                        srcDoc=open("./assets/parkmarker.html", "r").read(),
                        style={'height': '500px',
                               'width': '100%'})
        ])
    ])
])
